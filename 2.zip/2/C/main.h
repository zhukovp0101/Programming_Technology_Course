#include "A/index.h" 
#include "B/lib.h"

struct C_Class {
	int a = 0;
};